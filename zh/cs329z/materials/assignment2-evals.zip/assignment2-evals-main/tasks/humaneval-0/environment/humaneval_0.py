from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """Check whether any two numbers are closer than the given threshold.

    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    pass
