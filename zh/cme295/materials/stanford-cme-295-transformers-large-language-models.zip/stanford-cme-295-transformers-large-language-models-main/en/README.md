# Transformers & LLMs cheatsheet for Stanford's CME 295
Available in [العربية](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/ar) - [Čeština](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/cs) - **English** - [Español](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/es) - [فارسی](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/fa) - [Français](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/fr) - [Italiano](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/it) - [日本語](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/ja) - [한국어](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/ko) - [Português](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/pt) - [Русский](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/ru) - [Српски](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/sr) - [ไทย](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/th) - [Türkçe](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/tr) - [中文](https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/tree/main/zh)

## Goal
This repository aims at summing up in the same place all the important concepts that are covered in Stanford's CME 295 Transformers & Large Language Models course. It includes:
- **Transformers**: self-attention, architecture, variants
- **LLMs**: prompting, finetuning (SFT, LoRA), preference tuning (RLHF, DPO), reasoning (RLVR, OPD)
- **Optimizations**: Distributed training, KV caching, speculative decoding
- **Applications**: AI agents, evaluation, extensions (e.g. diffusion LLMs)

## Content
### VIP Cheatsheet
<a href="https://github.com/afshinea/stanford-cme-295-transformers-large-language-models/blob/main/en/cheatsheet-transformers-large-language-models.pdf"><img src="https://cme295.stanford.edu/cheatsheet-en.png?081b8d308a45a479ab17e5b6e4994484" alt="Illustration" width="600px"/></a>

## Class textbook
This VIP cheatsheet gives an overview of what is in the "Super Study Guide: Transformers & Large Language Models" book, which contains ~600 illustrations over 250 pages. You can find more details at https://superstudy.guide.

## Class website
[cme295.stanford.edu](https://cme295.stanford.edu/)

## Authors
[Afshine Amidi](https://www.linkedin.com/in/afshineamidi/) (Ecole Centrale Paris, MIT) and [Shervine Amidi](https://www.linkedin.com/in/shervineamidi/) (Ecole Centrale Paris, Stanford University)
